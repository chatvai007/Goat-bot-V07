const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "kiss",
    aliases: ["kisspic"],
    version: "3.1.0",
    author: "Rayhan",
    countDown: 5,
    role: 0,
    shortDescription: { en: "Send a kiss picture" },
    category: "fun",
    guide: { en: "{pn}" }
  },

  onStart: async function ({ message }) {
    const imagePath = path.join(__dirname, "kiss.png");

    if (!fs.existsSync(imagePath)) {
      return message.reply("❌ kiss.png ফাইলটি kiss.js-এর একই ফোল্ডারে নেই।");
    }

    return message.reply({
      body: "💋❤️ Kiss time! ❤️💋",
      attachment: fs.createReadStream(imagePath)
    });
  }
};
