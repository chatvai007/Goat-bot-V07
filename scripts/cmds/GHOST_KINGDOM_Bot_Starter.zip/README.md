# GHOST KINGDOM Bot Starter

এটি GoatBot/Messenger bot-এর জন্য একটি starter package। এটি তোমার আসল bot-এর fork নয়—কারণ framework/repository না দেখে সব 253টি command-এর working implementation নিশ্চিত করা যায় না।

## Included commands
- `!help` — এই প্যাকে থাকা command list
- `!wlc` — welcome message (join event hook সমর্থন করলে)
- `!sing <song>` — YouTube search result link
- `!chat <message>` — ছোট friendly Bangla reply

Owner label: Adrita  
Admin label: Rayhan

## Install
1. তোমার GoatBot project-এর backup নাও।
2. `scripts/cmds/` ফোল্ডারের ফাইলগুলো তোমার project-এর command folder-এ কপি করো।
3. `wlc.png`-এর জায়গায় নিজের welcome image রাখো।
4. তোমার framework-এর command loader ও event hooks-এর সঙ্গে মিলিয়ে নাও।
5. `npm start` চালিয়ে test করো।

## Important
- GoatBot fork-ভেদে command API আলাদা হতে পারে; তাই এই ফাইলগুলো সরাসরি সব fork-এ চলবে এমন নিশ্চয়তা নেই।
- GitHub Actions নিজে থেকে bot-কে 24/7 চালু রাখে না। Runner শেষ হলে process বন্ধ হতে পারে।
- `!sing` শুধু YouTube search link দেয়, অডিও ডাউনলোড করে না।
- সব 253টি command চালু করতে মূল repository/ZIP এবং প্রতিটি feature-এর implementation/dependencies লাগবে।
