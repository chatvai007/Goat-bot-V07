module.exports.config = {
  name: "help",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "GHOST KINGDOM",
  description: "Show available GHOST KINGDOM commands",
  commandCategory: "System",
  usages: "!help",
  cooldowns: 3
};

module.exports.run = async function ({ api, event }) {
  const msg = [
    "👑 GHOST KINGDOM — COMMANDS",
    "",
    "!help — command list",
    "!wlc — welcome message (manual test)",
    "!sing <song> — YouTube search link",
    "!chat <message> — friendly Bangla reply",
    "",
    "Owner: Adrita | Admin: Rayhan",
    "",
    "Note: তোমার দেওয়া 253টি নাম এই starter-এ সব কার্যকর নয়। মূল GoatBot source দিলে framework অনুযায়ী যোগ করতে হবে।"
  ].join("\n");
  return api.sendMessage(msg, event.threadID, event.messageID);
};
