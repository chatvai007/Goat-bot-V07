module.exports.config = {
  name: "sing",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "GHOST KINGDOM",
  description: "Find a song on YouTube",
  commandCategory: "Music",
  usages: "!sing <song name>",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args }) {
  const query = (args || []).join(" ").trim();
  if (!query) return api.sendMessage("গানের নাম দাও। উদাহরণ: !sing Amake Amar Moto Thakte Dao", event.threadID, event.messageID);
  const url = "https://www.youtube.com/results?search_query=" + encodeURIComponent(query);
  return api.sendMessage("🎵 YouTube-এ খুঁজে দেখো:\n" + url, event.threadID, event.messageID);
};
