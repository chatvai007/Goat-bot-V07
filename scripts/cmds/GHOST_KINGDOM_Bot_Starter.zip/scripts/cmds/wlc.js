module.exports.config = {
  name: "wlc",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Rayhan",
  description: "GHOST KINGDOM welcome message",
  commandCategory: "Group",
  usages: "!wlc",
  cooldowns: 5
};

module.exports.run = async function ({ api, event }) {
  const text = "👑 Welcome to GHOST KINGDOM 👑\nOwner: Adrita\nAdmin: Rayhan\nসবাইকে সম্মান করুন এবং গ্রুপের নিয়ম মেনে চলুন!";
  return api.sendMessage(text, event.threadID, event.messageID);
};
