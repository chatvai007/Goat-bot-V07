module.exports.config = {
  name: "chat",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "GHOST KINGDOM",
  description: "Friendly Bangla chat replies",
  commandCategory: "Fun",
  usages: "!chat <message>",
  cooldowns: 3
};

const replies = [
  "হাহা 😂 GHOST KINGDOM হাজির!",
  "কী খবর? 👻",
  "চলো সবাই মিলে গ্রুপটা মজার রাখি 😎",
  "Owner Adrita আর Admin Rayhan-এর পক্ষ থেকে শুভেচ্ছা! 👑",
  "বুঝলাম 😄 আর বলো!"
];

module.exports.run = async function ({ api, event, args }) {
  const input = (args || []).join(" ").trim();
  if (!input) return api.sendMessage("আমার সাথে কথা বলতে লিখো: !chat কেমন আছো", event.threadID, event.messageID);
  const idx = Math.floor(Math.random() * replies.length);
  return api.sendMessage(replies[idx], event.threadID, event.messageID);
};
