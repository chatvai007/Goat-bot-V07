# GHOST KINGDOM GoatBot Custom Pack

Customized command pack:
- `scripts/cmds/sing.js` — searches YouTube and sends a link to the result.
- `scripts/cmds/wlc.js` — sends the GHOST KINGDOM welcome card and `wlc.png`.
- `scripts/cmds/help.js` — lists these commands.
- `.github/workflows/bot.yml` — basic GitHub Actions workflow.

## Important
This ZIP is a **customization pack**, not the full GoatBot framework. Add these files to a compatible GoatBot V07 repository. Do not replace the framework's existing `package.json`, lockfile, login/config files, or other workflow unless you know they are safe to replace.

## Install
1. Upload the three `.js` files into your GoatBot command folder (commonly `scripts/cmds/`).
2. Keep `wlc.png` beside `wlc.js`.
3. In the existing repository's `package.json`, add `yt-search` to dependencies, or run `npm install yt-search` in the repository and commit the updated `package.json` and lockfile.
4. Check that `npm start` is the correct start command for your repository before enabling the workflow.
5. Upload `.github/workflows/bot.yml` only if you need this workflow; if your repository already has a working workflow, merge the steps rather than creating duplicate bot processes.

## Notes
- `!sing` searches YouTube and returns the result link; it does not download copyrighted songs or send a downloaded audio file.
- Use only audio you own or are authorized to share if you later add direct audio attachments.
- Never commit Messenger cookies, app state, access tokens, or other secrets. Use GitHub Actions Secrets for sensitive values.
- GitHub-hosted runners are temporary; this workflow runs only while the Actions job is active and is not a permanent 24/7 host.
- The command API (`onStart`, `api.sendMessage`) must match the GoatBot version you use. Adjust if your fork uses a different command interface.
