const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "wlc",
    version: "1.0.0",
    author: "Rayhan",
    role: 0,
    description: { en: "Send GHOST KINGDOM welcome card" },
    category: "group",
    guide: { en: "{pn}" }
  },

  onStart: async ({ api, event }) => {
    const imagePath = path.join(__dirname, "wlc.png");
    const message =
      "╭━━━〔 👑 GHOST KINGDOM 〕━━━╮\n" +
      "স্বাগতম! 🖤\n" +
      "Owner: Adrita\n" +
      "Admin: Rayhan\n" +
      "সবাই নিয়ম মেনে বন্ধুত্বপূর্ণ পরিবেশ বজায় রাখো।\n" +
      "╰━━━━━━━━━━━━━━━━━━━━╯";

    if (fs.existsSync(imagePath)) {
      return api.sendMessage(
        { body: message, attachment: fs.createReadStream(imagePath) },
        event.threadID,
        event.messageID
      );
    }

    return api.sendMessage(message, event.threadID, event.messageID);
  }
};
