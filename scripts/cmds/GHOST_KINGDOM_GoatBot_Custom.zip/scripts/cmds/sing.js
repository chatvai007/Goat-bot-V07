const ytSearch = require("yt-search");

module.exports = {
  config: {
    name: "sing",
    version: "1.0.0",
    author: "Rayhan",
    role: 0,
    description: { en: "Search for a song on YouTube" },
    category: "music",
    guide: { en: "{pn} song name" }
  },

  onStart: async ({ api, args, event }) => {
    const keyword = args.join(" ").trim();
    if (!keyword) {
      return api.sendMessage(
        "🎵 ব্যবহার: !sing Believer\nগানের নাম লিখে সার্চ করো।",
        event.threadID,
        event.messageID
      );
    }

    try {
      const results = await ytSearch(keyword);
      const video = results.videos && results.videos[0];

      if (!video) {
        return api.sendMessage("❌ কোনো ফলাফল পাওয়া যায়নি।", event.threadID, event.messageID);
      }

      const message =
        "╭━━━〔 🎧 GHOST KINGDOM 〕━━━╮\n" +
        "🎵 গান: " + video.title + "\n" +
        "📺 চ্যানেল: " + (video.author && video.author.name ? video.author.name : "Unknown") + "\n" +
        "⏱️ সময়: " + (video.timestamp || "Unknown") + "\n\n" +
        "▶️ শুনতে এখানে চাপ দাও:\n" + video.url + "\n" +
        "╰━━━━━━━━━━━━━━━━━━━━╯";

      return api.sendMessage(message, event.threadID, event.messageID);
    } catch (err) {
      console.error("[SING ERROR]", err);
      return api.sendMessage(
        "❌ গান খুঁজতে সমস্যা হয়েছে। পরে আবার চেষ্টা করো।",
        event.threadID,
        event.messageID
      );
    }
  }
};
