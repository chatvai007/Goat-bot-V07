module.exports = {
  config: {
    name: "help",
    version: "1.0.0",
    author: "Rayhan",
    role: 0,
    description: { en: "Show GHOST KINGDOM command list" },
    category: "info",
    guide: { en: "{pn}" }
  },

  onStart: async ({ api, event }) => {
    const message =
      "╭━━━〔 👑 GHOST KINGDOM BOT 〕━━━╮\n" +
      "🎵 !sing <গানের নাম> — YouTube-এ গান খুঁজুন\n" +
      "👋 !wlc — Welcome card পাঠান\n" +
      "🤖 !help — কমান্ডের তালিকা\n\n" +
      "Owner: Adrita\n" +
      "Admin: Rayhan\n" +
      "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯";
    return api.sendMessage(message, event.threadID, event.messageID);
  }
};
